from time import sleep
import keyboard

keyboard.write("ls")
sleep(1)
keyboard.press('enter')
sleep(1)
keyboard.write(" humannotexist3.jpg")
keyboard.press('enter')
print("here is a photo of jignesh")